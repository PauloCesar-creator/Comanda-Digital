import React, { useState, useMemo } from 'react';
import { DollarSign, TrendingUp, Users, Settings, Lock, FileText, X, Calendar, ChevronDown, ChevronRight } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';
import { Transaction } from '../types';

interface AdminPageProps {
    history: Transaction[];
}

export const AdminPage: React.FC<AdminPageProps> = ({ history }) => {
    // --- Auth State ---
    const [isAuthenticated, setIsAuthenticated] = useState(false);
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [loginError, setLoginError] = useState('');

    // --- Report Modal State ---
    const [isReportOpen, setIsReportOpen] = useState(false);

    // --- Data Processing for Dashboard ---
    const dashboardData = useMemo(() => {
        const today = new Date();
        const startOfToday = new Date(today.getFullYear(), today.getMonth(), today.getDate()).getTime();
        
        // Revenue Today
        const revenueToday = history
            .filter(t => new Date(t.date).getTime() >= startOfToday)
            .reduce((acc, t) => acc + t.total, 0);

        // Active Customers (Approximation based on recent transactions or just place holder as we don't have live table count prop here)
        // For accurate active tables, we would need the `tables` prop, but let's use transaction count today as a proxy for "Sold Tables"
        const salesCountToday = history.filter(t => new Date(t.date).getTime() >= startOfToday).length;

        // Chart Data (Last 7 Days)
        const chartData = [];
        const days = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'];
        
        for (let i = 6; i >= 0; i--) {
            const d = new Date();
            d.setDate(d.getDate() - i);
            const dateStr = d.toLocaleDateString('pt-BR');
            const dayName = i === 0 ? 'Hoje' : days[d.getDay()];

            // Calculate total for this specific day
            const dayStart = new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime();
            const dayEnd = dayStart + 86400000;
            
            const dayTotal = history
                .filter(t => {
                    const tTime = new Date(t.date).getTime();
                    return tTime >= dayStart && tTime < dayEnd;
                })
                .reduce((acc, t) => acc + t.total, 0);

            chartData.push({ name: dayName, v: dayTotal });
        }

        return { revenueToday, salesCountToday, chartData };
    }, [history]);

    // --- Data Processing for Report Modal ---
    const groupedHistory = useMemo<{ [key: string]: Transaction[] }>(() => {
        const grouped: { [date: string]: Transaction[] } = {};
        
        // Sort by date descending
        const sorted = [...history].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        sorted.forEach(t => {
            const dateKey = new Date(t.date).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' });
            if (!grouped[dateKey]) grouped[dateKey] = [];
            grouped[dateKey].push(t);
        });

        return grouped;
    }, [history]);

    // --- Handlers ---
    const handleLogin = (e: React.FormEvent) => {
        e.preventDefault();
        if (username === 'caixa' && password === '2345') {
            setIsAuthenticated(true);
            setLoginError('');
        } else {
            setLoginError('Credenciais inválidas');
        }
    };

    // --- Render: Login Screen ---
    if (!isAuthenticated) {
        return (
            <div className="min-h-screen bg-dark-900 flex flex-col items-center justify-center p-6 text-white pb-32">
                <div className="w-full max-w-sm bg-dark-800 p-8 rounded-2xl border border-dark-700 shadow-2xl">
                    <div className="flex justify-center mb-6 text-primary-500">
                        <div className="bg-dark-700 p-4 rounded-full">
                            <Lock size={32} />
                        </div>
                    </div>
                    <h2 className="text-2xl font-bold text-center mb-2">Acesso Restrito</h2>
                    <p className="text-gray-400 text-center text-sm mb-8">Digite suas credenciais de administrador</p>
                    
                    <form onSubmit={handleLogin} className="space-y-4">
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1 block">Usuário</label>
                            <input 
                                type="text" 
                                value={username}
                                onChange={e => setUsername(e.target.value)}
                                className="w-full bg-dark-900 border border-dark-600 rounded-xl p-3 text-white focus:border-primary-500 focus:outline-none"
                            />
                        </div>
                        <div>
                            <label className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-1 block">Senha</label>
                            <input 
                                type="password" 
                                value={password}
                                onChange={e => setPassword(e.target.value)}
                                className="w-full bg-dark-900 border border-dark-600 rounded-xl p-3 text-white focus:border-primary-500 focus:outline-none"
                            />
                        </div>
                        
                        {loginError && <p className="text-red-500 text-sm text-center">{loginError}</p>}

                        <button type="submit" className="w-full bg-primary-500 text-dark-900 font-bold py-3 rounded-xl hover:bg-primary-600 transition-colors mt-2">
                            Entrar
                        </button>
                    </form>
                </div>
            </div>
        );
    }

    // --- Render: Dashboard ---
    return (
        <div className="min-h-screen bg-dark-800 text-white p-6 pb-24 relative">
            <header className="flex justify-between items-center mb-8">
                <h1 className="text-2xl font-bold">Dashboard</h1>
                <button onClick={() => setIsAuthenticated(false)} className="p-2 bg-dark-700 rounded-full hover:bg-dark-600 transition-colors text-red-400">
                    <Lock size={20} />
                </button>
            </header>

            {/* Stats Cards */}
            <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-dark-700 p-4 rounded-xl border border-dark-600">
                    <div className="flex items-center gap-2 text-gray-400 mb-2">
                        <DollarSign size={16} />
                        <span className="text-xs uppercase font-bold">Faturamento (Dia)</span>
                    </div>
                    <p className="text-2xl font-bold text-accent-green">R$ {dashboardData.revenueToday.toFixed(2)}</p>
                </div>
                <div className="bg-dark-700 p-4 rounded-xl border border-dark-600">
                    <div className="flex items-center gap-2 text-gray-400 mb-2">
                        <Users size={16} />
                        <span className="text-xs uppercase font-bold">Vendas (Dia)</span>
                    </div>
                    <p className="text-2xl font-bold text-primary-500">{dashboardData.salesCountToday}</p>
                </div>
            </div>

            {/* Chart Section */}
            <div className="bg-dark-700 rounded-xl p-4 border border-dark-600 mb-6">
                <div className="flex items-center gap-2 mb-6">
                    <TrendingUp size={20} className="text-primary-500" />
                    <h3 className="font-bold">Histórico (7 Dias)</h3>
                </div>
                <div className="h-48 w-full">
                    <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={dashboardData.chartData}>
                            <XAxis dataKey="name" stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} />
                            <YAxis stroke="#64748b" fontSize={10} tickLine={false} axisLine={false} tickFormatter={(value) => `k${(value/1000).toFixed(0)}`} />
                            <Tooltip 
                                contentStyle={{ backgroundColor: '#1e293b', border: 'none', borderRadius: '8px', color: '#fff' }}
                                cursor={{fill: '#2a3441'}}
                                formatter={(value: number) => [`R$ ${value.toFixed(2)}`, 'Venda']}
                            />
                            <Bar dataKey="v" fill="#F59E0B" radius={[4, 4, 0, 0]} />
                        </BarChart>
                    </ResponsiveContainer>
                </div>
            </div>
            
            {/* Quick Actions */}
            <div className="space-y-3">
                <button className="w-full bg-dark-700 p-4 rounded-xl text-left flex justify-between items-center hover:bg-dark-600 transition-colors opacity-50 cursor-not-allowed">
                    <div className="flex items-center gap-3">
                        <Settings size={20} className="text-gray-400" />
                        <span className="font-semibold text-gray-300">Gerenciar Cardápio</span>
                    </div>
                    <span className="text-gray-500 text-2xl">›</span>
                </button>
                <button 
                    onClick={() => setIsReportOpen(true)}
                    className="w-full bg-dark-700 p-4 rounded-xl text-left flex justify-between items-center hover:bg-dark-600 transition-colors border border-dark-600"
                >
                    <div className="flex items-center gap-3">
                        <FileText size={20} className="text-primary-500" />
                        <span className="font-semibold text-white">Relatório de Caixa</span>
                    </div>
                    <span className="text-gray-500 text-2xl">›</span>
                </button>
            </div>

            {/* --- REPORT MODAL --- */}
            {isReportOpen && (
                <div className="fixed inset-0 bg-black/90 z-50 flex items-end sm:items-center justify-center sm:p-4 backdrop-blur-sm animate-in fade-in">
                    <div className="bg-dark-800 w-full sm:max-w-md h-[90vh] rounded-t-3xl sm:rounded-3xl border border-dark-700 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-10">
                        <div className="p-6 border-b border-dark-700 flex justify-between items-center bg-dark-800">
                            <div>
                                <h3 className="text-xl font-bold text-white">Relatório de Caixa</h3>
                                <p className="text-xs text-gray-500 mt-1">Histórico dos últimos 5 dias</p>
                            </div>
                            <button onClick={() => setIsReportOpen(false)} className="p-2 bg-dark-700 rounded-full text-gray-400 hover:text-white"><X size={20} /></button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
                            {Object.keys(groupedHistory).length === 0 ? (
                                <div className="h-full flex flex-col items-center justify-center text-gray-500 opacity-50">
                                    <FileText size={40} className="mb-2" />
                                    <p>Nenhum registro encontrado</p>
                                </div>
                            ) : (
                                Object.entries(groupedHistory).map(([date, transactions]: [string, Transaction[]]) => (
                                    <div key={date} className="mb-6 last:mb-0">
                                        <div className="sticky top-0 bg-dark-800/95 backdrop-blur-sm py-2 px-2 border-b border-primary-500/30 mb-2 z-10">
                                            <h4 className="text-primary-500 font-bold text-sm uppercase flex items-center gap-2">
                                                <Calendar size={14} />
                                                {date}
                                            </h4>
                                        </div>
                                        <div className="space-y-2">
                                            {transactions.map(t => (
                                                <div key={t.id} className="bg-dark-700 p-3 rounded-xl flex justify-between items-center border border-dark-600/50">
                                                    <div>
                                                        <div className="flex items-center gap-2">
                                                            <span className="text-white font-bold">{t.tableName}</span>
                                                            <span className="text-gray-500 text-xs bg-dark-900 px-1.5 rounded">{t.timestamp}</span>
                                                        </div>
                                                        <p className="text-xs text-gray-400 mt-0.5">{t.itemsSummary}</p>
                                                    </div>
                                                    <span className="text-accent-green font-bold text-sm">R$ {t.total.toFixed(2)}</span>
                                                </div>
                                            ))}
                                            {/* Daily Total */}
                                            <div className="flex justify-end pt-2 px-2">
                                                <span className="text-xs text-gray-400 mr-2 uppercase font-bold">Total do dia:</span>
                                                <span className="text-white font-bold">
                                                    R$ {transactions.reduce((acc, t) => acc + t.total, 0).toFixed(2)}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

        </div>
    );
};