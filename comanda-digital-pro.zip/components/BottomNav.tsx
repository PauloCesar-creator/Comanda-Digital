import React from 'react';
import { UtensilsCrossed, LayoutGrid, Flame, PieChart } from 'lucide-react';
import { Page } from '../types';

interface BottomNavProps {
  activePage: Page;
  setPage: (page: Page) => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({ activePage, setPage }) => {
  const navItems = [
    { id: Page.MENU, label: 'Cardápio', icon: UtensilsCrossed },
    { id: Page.TABLES, label: 'Mesas', icon: LayoutGrid },
    { id: Page.KITCHEN, label: 'Cozinha', icon: Flame },
    { id: Page.ADMIN, label: 'Admin', icon: PieChart },
  ];

  return (
    <div className="fixed bottom-0 left-0 w-full bg-dark-800 border-t border-dark-600 pb-safe z-50">
      <div className="flex justify-around items-center h-16 max-w-md mx-auto">
        {navItems.map((item) => {
          const isActive = activePage === item.id;
          const Icon = item.icon;
          
          return (
            <button
              key={item.id}
              onClick={() => setPage(item.id)}
              className={`flex flex-col items-center justify-center w-full h-full transition-colors duration-200 ${
                isActive ? 'text-accent-green' : 'text-gray-500 hover:text-gray-300'
              }`}
            >
              <Icon size={24} strokeWidth={isActive ? 2.5 : 2} className="mb-1" />
              <span className="text-[10px] font-medium tracking-wide uppercase">{item.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};