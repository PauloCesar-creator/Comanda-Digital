import React, { useState } from 'react';
import { Table as TableType } from '../types';
import { X, Trash2, Receipt, CheckCircle2, Ban, Plus, User, DollarSign } from 'lucide-react';

interface TablesPageProps {
  tables: TableType[];
  onAddTable: (name: string) => void;
  onRemoveItem: (tableId: number, instanceId: string) => void;
  onConfirmPayment: (tableId: number, amount: number) => void;
}

export const TablesPage: React.FC<TablesPageProps> = ({ tables, onAddTable, onRemoveItem, onConfirmPayment }) => {
  const [selectedTable, setSelectedTable] = useState<TableType | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [newTableName, setNewTableName] = useState('');

  // Helper to calculate totals logic
  const calculateTotal = (table: TableType) => {
    const subtotal = table.items.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const serviceFee = subtotal * 0.10;
    const total = subtotal + serviceFee;
    return { subtotal, serviceFee, total };
  };

  const handlePaymentWithTax = () => {
    if (selectedTable) {
        const { total } = calculateTotal(selectedTable);
        onConfirmPayment(selectedTable.id, total);
        setSelectedTable(null);
    }
  };

  const handlePaymentWithoutTax = () => {
    if (selectedTable) {
        const { subtotal } = calculateTotal(selectedTable);
        onConfirmPayment(selectedTable.id, subtotal);
        setSelectedTable(null);
    }
  };

  const handleAddTableSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTableName.trim()) {
        onAddTable(newTableName);
        setNewTableName('');
        setIsAddModalOpen(false);
    }
  };

  return (
    <div className="h-full flex flex-col bg-dark-900 text-white relative">
      {/* Header Simples */}
      <header className="px-6 py-6 bg-dark-900 z-10">
        <h1 className="text-2xl font-bold tracking-tight text-white">Gerenciar Mesas</h1>
        <p className="text-sm text-gray-500">Selecione uma mesa para ver detalhes</p>
      </header>

      {/* Grid Container */}
      <div className="flex-1 overflow-y-auto px-6 pb-32 custom-scrollbar">
        <div className="grid grid-cols-3 gap-4">
            {tables.map((table) => {
                const isOccupied = table.status === 'occupied';
                
                return (
                    <button 
                        key={table.id}
                        onClick={() => setSelectedTable(table)}
                        className={`
                            aspect-square rounded-2xl flex flex-col items-center justify-between p-3 transition-all duration-200 relative overflow-hidden group
                            ${isOccupied 
                                ? 'bg-dark-800 border border-red-500/50 shadow-[0_0_15px_-5px_rgba(239,68,68,0.2)]' 
                                : 'bg-dark-800 border border-dark-700 hover:border-primary-500/50 hover:bg-dark-700'
                            }
                        `}
                    >
                        {/* Status Dot */}
                        <div className={`w-full flex justify-end`}>
                            <div className={`w-2 h-2 rounded-full ${isOccupied ? 'bg-red-500 shadow-sm shadow-red-500' : 'bg-primary-500/50'}`}></div>
                        </div>

                        {/* Center Content - Name Only */}
                        <div className="flex flex-col items-center justify-center w-full flex-1 px-1">
                            <span className={`text-lg font-bold text-center line-clamp-3 leading-tight break-words w-full ${isOccupied ? 'text-white' : 'text-primary-500'}`}>
                                {table.name}
                            </span>
                        </div>

                        {/* Bottom Label */}
                        <div className={`
                            w-full py-1 rounded-md text-[9px] font-bold uppercase tracking-wider text-center mt-1
                            ${isOccupied 
                                ? 'bg-red-500/10 text-red-500' 
                                : 'bg-dark-700 text-gray-500 group-hover:text-primary-500 transition-colors'
                            }
                        `}>
                            {isOccupied ? 'Ocupada' : 'Livre'}
                        </div>
                    </button>
                );
            })}

            {/* Add Button Card */}
            <button 
                onClick={() => setIsAddModalOpen(true)}
                className="aspect-square rounded-2xl border-2 border-dashed border-dark-700 flex flex-col items-center justify-center text-dark-600 hover:text-primary-500 hover:border-primary-500 hover:bg-primary-500/5 transition-all gap-2 group"
            >
                <div className="w-10 h-10 rounded-full bg-dark-800 flex items-center justify-center group-hover:bg-primary-500 group-hover:text-dark-900 transition-colors">
                    <Plus size={20} />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-wide">Nova Mesa</span>
            </button>
        </div>
      </div>

      {/* --- ADD TABLE MODAL --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-6 backdrop-blur-sm animate-in fade-in duration-200">
             <div className="bg-dark-800 w-full max-w-sm rounded-2xl p-6 border border-dark-700 shadow-2xl">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-white">Abrir Nova Mesa</h3>
                    <button onClick={() => setIsAddModalOpen(false)} className="text-gray-500 hover:text-white transition-colors"><X size={24} /></button>
                </div>
                <form onSubmit={handleAddTableSubmit}>
                    <div className="bg-dark-900/50 rounded-xl p-6 border border-dark-700 mb-6 flex flex-col gap-2">
                        <label className="text-xs font-bold text-primary-500 uppercase tracking-wider">Nome da Mesa / Cliente</label>
                        <input 
                            type="text" 
                            value={newTableName} 
                            onChange={(e) => setNewTableName(e.target.value)} 
                            placeholder="Ex: Mesa 10"
                            className="w-full bg-transparent border-none text-white focus:ring-0 p-0 text-3xl font-bold placeholder-dark-600"
                            autoFocus
                        />
                    </div>
                    <button type="submit" className="w-full bg-primary-500 text-dark-900 font-bold py-4 rounded-xl hover:bg-primary-600 transition-colors shadow-lg shadow-orange-500/20">
                        Criar Mesa
                    </button>
                </form>
             </div>
        </div>
      )}

      {/* --- BILL / DETAILS MODAL --- */}
      {selectedTable && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-end sm:items-center justify-center sm:p-4 backdrop-blur-sm animate-in fade-in duration-200">
            <div className="bg-dark-800 w-full sm:max-w-md h-[90vh] sm:h-auto sm:max-h-[90vh] rounded-t-3xl sm:rounded-3xl border-t sm:border border-dark-700 shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-10 duration-300">
                
                {/* Optimized Header */}
                <div className="px-6 py-5 bg-dark-800 border-b border-dashed border-dark-600 flex justify-between items-start">
                    <div>
                        <div className="flex items-center gap-2 mb-1">
                            <span className="w-2 h-2 rounded-full bg-accent-green animate-pulse"></span>
                            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Cupom de Conferência</span>
                        </div>
                        <h3 className="font-bold text-2xl text-white leading-none">{selectedTable.name}</h3>
                    </div>
                    <button onClick={() => setSelectedTable(null)} className="w-8 h-8 -mr-2 bg-dark-700 rounded-full flex items-center justify-center text-gray-400 hover:text-white transition-colors">
                        <X size={16} />
                    </button>
                </div>

                {/* Optimized List - "Receipt Style" */}
                <div className="flex-1 overflow-y-auto px-6 py-4 bg-dark-900/50 space-y-3">
                    {selectedTable.items.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center text-gray-600 space-y-3 opacity-50">
                            <Receipt size={40} strokeWidth={1.5} />
                            <p className="text-sm font-medium">Comanda vazia</p>
                        </div>
                    ) : (
                        selectedTable.items.map((item) => (
                            <div key={item.instanceId} className="flex justify-between items-center group py-1 border-b border-dark-800 last:border-0">
                                <div className="flex items-center gap-3 overflow-hidden">
                                    <span className="text-xs font-bold text-primary-500 min-w-[1.5rem]">{item.quantity}x</span>
                                    <div className="flex flex-col">
                                        <span className="text-sm text-gray-200 font-medium truncate">{item.name}</span>
                                        <span className="text-[10px] text-gray-500">un. R$ {item.price.toFixed(2)}</span>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3 pl-2">
                                    <span className="text-sm font-bold text-white tabular-nums">
                                        R$ {(item.price * item.quantity).toFixed(2)}
                                    </span>
                                    <button 
                                        onClick={() => onRemoveItem(selectedTable.id, item.instanceId)}
                                        className="text-dark-600 hover:text-red-500 transition-colors"
                                    >
                                        <Trash2 size={14} />
                                    </button>
                                </div>
                            </div>
                        ))
                    )}
                </div>

                {/* Footer Totals & Optimized Actions */}
                <div className="p-6 bg-dark-800 border-t border-dark-700 shadow-[0_-5px_20px_rgba(0,0,0,0.3)] z-10">
                    {(() => {
                        const { subtotal, serviceFee, total } = calculateTotal(selectedTable);
                        const hasItems = selectedTable.items.length > 0;
                        
                        return (
                            <div className="space-y-4">
                                {/* Totals Summary */}
                                <div className="space-y-1 pb-4 border-b border-dashed border-dark-600">
                                    <div className="flex justify-between text-xs text-gray-400">
                                        <span>Subtotal</span>
                                        <span className="tabular-nums">R$ {subtotal.toFixed(2)}</span>
                                    </div>
                                    <div className="flex justify-between text-xs text-gray-400">
                                        <span>Serviço (10%)</span>
                                        <span className="tabular-nums">R$ {serviceFee.toFixed(2)}</span>
                                    </div>
                                </div>
                                
                                <div className="flex justify-between items-end pb-2">
                                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total a Pagar</span>
                                    <div className="flex items-baseline gap-1 text-accent-green">
                                        <span className="text-sm font-bold">R$</span>
                                        <span className="text-3xl font-bold tracking-tight">{total.toFixed(2)}</span>
                                    </div>
                                </div>
                                
                                {/* Action Buttons */}
                                <div className="flex flex-col gap-3 pt-2">
                                    <button 
                                        onClick={handlePaymentWithTax}
                                        disabled={!hasItems}
                                        className="w-full py-4 px-4 rounded-xl bg-accent-green text-dark-900 font-bold text-sm hover:bg-emerald-400 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 shadow-lg shadow-emerald-900/20"
                                    >
                                        <CheckCircle2 size={18} strokeWidth={2.5} />
                                        <span>Confirmar Pagamento</span>
                                    </button>

                                    <button 
                                        onClick={handlePaymentWithoutTax}
                                        disabled={!hasItems}
                                        className="w-full py-3 px-4 rounded-xl border border-dark-600 text-gray-400 font-bold text-xs hover:border-gray-400 hover:text-white transition-colors disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                                    >
                                        <Ban size={14} />
                                        <span>Confirmar Pagamento (Sem Taxa)</span>
                                    </button>
                                </div>
                            </div>
                        );
                    })()}
                </div>
            </div>
        </div>
      )}
    </div>
  );
};