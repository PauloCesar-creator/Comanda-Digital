import React, { useState, useEffect } from 'react';
import { MenuPage } from './pages/Menu';
import { TablesPage } from './pages/Tables';
import { KitchenPage } from './pages/Kitchen';
import { AdminPage } from './pages/Admin';
import { BottomNav } from './components/BottomNav';
import { Page, Table, Order, Product, TableItem, Transaction } from './types';
import { CheckCircle2 } from 'lucide-react';

// --- DEFAULT MENU DATA ---
const DEFAULT_MENU_ITEMS: Product[] = [
  // PRATO 1
  { id: 'p1-1', name: 'Filé de Tilápia (porção 400g)', price: 60.00, category: 'prato1', image: 'https://images.unsplash.com/photo-1599084993091-1e832fda2d43?w=400&q=80' },
  { id: 'p1-2', name: 'Costela de Caranha (porção 500g)', price: 60.00, category: 'prato1', image: 'https://images.unsplash.com/photo-1544025162-d76694265947?w=400&q=80' },
  { id: 'p1-3', name: 'Ovo de codorna (unidade)', price: 0.60, category: 'prato1', image: 'https://images.unsplash.com/photo-1591460384462-84950d3c051e?w=400&q=80' },
  { id: 'p1-4', name: 'Picanha Acebolada (porção 400g)', price: 90.00, category: 'prato1', image: 'https://images.unsplash.com/photo-1558030006-450675393462?w=400&q=80' },
  { id: 'p1-5', name: 'Anel de Cebola', price: 20.00, category: 'prato1', image: 'https://images.unsplash.com/photo-1639024471283-03518883512d?w=400&q=80' },
  { id: 'p1-6', name: 'Camarão Empanado', price: 90.00, category: 'prato1', image: 'https://images.unsplash.com/photo-1623961990059-28356e22bc8e?w=400&q=80' },

  // PRATO 2
  { id: 'p2-1', name: 'Asinha de Frango (porção 800g)', price: 45.00, category: 'prato2', image: 'https://images.unsplash.com/photo-1567620832903-9fc6debc209f?w=400&q=80' },
  { id: 'p2-2', name: 'Frango a Passarinho (porção 800g)', price: 40.00, category: 'prato2', image: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?w=400&q=80' },
  { id: 'p2-3', name: 'Batata Frita (porção 400g)', price: 30.00, category: 'prato2', image: 'https://images.unsplash.com/photo-1573080496987-a199f8cd75c5?w=400&q=80' },
  { id: 'p2-4', name: 'Batata Frita c/ Bacon e Cheddar (400g)', price: 35.00, category: 'prato2', image: 'https://images.unsplash.com/photo-1585109649139-3668018951a7?w=400&q=80' },
  { id: 'p2-5', name: 'Mandioca (porção 400g)', price: 20.00, category: 'prato2', image: 'https://images.unsplash.com/photo-1615887023516-9b6e51f4c287?w=400&q=80' },

  // BEBIDAS (ALCOOL)
  { id: 'alc-1', name: 'Cervejas (Antartica, Brahma, Skol, Bud, Amstel)', price: 5.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1600788886242-5c96aabe3757?w=400&q=80', isAlcoholic: true },
  { id: 'alc-2', name: 'Heineken Lata', price: 6.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1575490656649-4f762f0f78d6?w=400&q=80', isAlcoholic: true },
  { id: 'alc-3', name: 'Stella Gold', price: 6.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1623253507664-88db09a5b3a8?w=400&q=80', isAlcoholic: true },
  { id: 'alc-4', name: 'Spaten', price: 6.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1662973787752-67858342417e?w=400&q=80', isAlcoholic: true },
  { id: 'alc-5', name: 'Corona', price: 7.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1605253243167-9d747d526e0b?w=400&q=80', isAlcoholic: true },
  { id: 'alc-6', name: 'Campari', price: 25.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1562688082-f32df635dc90?w=400&q=80', isAlcoholic: true },
  { id: 'alc-7', name: 'Conhaque (Diversos)', price: 7.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1616641838893-1b0587293a68?w=400&q=80', isAlcoholic: true },
  { id: 'alc-8', name: 'Pingas (Diversas)', price: 4.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=400&q=80', isAlcoholic: true },
  { id: 'alc-9', name: 'Vodka (Dose)', price: 8.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1606168094336-42f9b16b29d3?w=400&q=80', isAlcoholic: true },
  { id: 'alc-10', name: 'Whisky', price: 25.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1527281400683-1aadd77921e5?w=400&q=80', isAlcoholic: true },
  { id: 'alc-11', name: 'Old Par, Jack Daniels', price: 30.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1558485202-b2584d436c64?w=400&q=80', isAlcoholic: true },
  { id: 'alc-12', name: 'Caipirosca c/ Vodka', price: 30.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1579730303792-747d92823055?w=400&q=80', isAlcoholic: true },
  { id: 'alc-13', name: 'Caipirinha c/ Pinga', price: 25.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&q=80', isAlcoholic: true },
  { id: 'alc-14', name: 'Smirnoff Lata', price: 12.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1624637651086-444a5009f984?w=400&q=80', isAlcoholic: true },
  { id: 'alc-15', name: 'Paratudo', price: 4.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1596706066268-23136208577e?w=400&q=80', isAlcoholic: true },
  { id: 'alc-16', name: 'Gin Tônica Lata', price: 10.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1601633513364-74c106511394?w=400&q=80', isAlcoholic: true },
  { id: 'alc-17', name: 'Cerveja Michelob', price: 7.00, category: 'alcohol', image: 'https://images.unsplash.com/photo-1647427843621-c4d92209d64a?w=400&q=80', isAlcoholic: true },

  // SEM ALCOOL
  { id: 'drk-1', name: 'Agua Mineral S/ Gás', price: 3.00, category: 'drink', image: 'https://images.unsplash.com/photo-1564414277413-4a3b19136394?w=400&q=80' },
  { id: 'drk-2', name: 'Agua Mineral C/ Gás', price: 4.00, category: 'drink', image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&q=80' },
  { id: 'drk-3', name: 'Refri Lata', price: 6.00, category: 'drink', image: 'https://images.unsplash.com/photo-1622483767128-342797214a93?w=400&q=80' },
  { id: 'drk-4', name: 'Suco Caixinha', price: 4.00, category: 'drink', image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&q=80' },
  { id: 'drk-5', name: 'Agua Tônica', price: 6.00, category: 'drink', image: 'https://images.unsplash.com/photo-1598614187854-26a60e982dc4?w=400&q=80' },
  { id: 'drk-6', name: 'Red Bull Lata', price: 14.00, category: 'drink', image: 'https://images.unsplash.com/photo-1551329621-c45353d264f3?w=400&q=80' },
  { id: 'drk-7', name: 'Energético Lata', price: 10.00, category: 'drink', image: 'https://images.unsplash.com/photo-1622543925917-763c34d1a86e?w=400&q=80' },
  { id: 'drk-8', name: 'Guaraná 1,5L', price: 10.00, category: 'drink', image: 'https://images.unsplash.com/photo-1582230495810-705886915b4f?w=400&q=80' },
  { id: 'drk-9', name: 'Coca Cola 2L', price: 15.00, category: 'drink', image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?w=400&q=80' },
  { id: 'drk-10', name: 'Fanta 2L', price: 14.00, category: 'drink', image: 'https://images.unsplash.com/photo-1624517452488-04869289c4ca?w=400&q=80' },
  { id: 'drk-11', name: 'Cerveja S/ Alcool', price: 6.00, category: 'drink', image: 'https://images.unsplash.com/photo-1566633806327-68e152aaf26d?w=400&q=80' },
  { id: 'drk-12', name: 'Agua Mineral 1L', price: 7.00, category: 'drink', image: 'https://images.unsplash.com/photo-1603394630850-69b3ca8121ca?w=400&q=80' },
  { id: 'drk-13', name: 'H2O Limoneto', price: 8.00, category: 'drink', image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?w=400&q=80' },
  { id: 'drk-14', name: 'Gatorade', price: 8.00, category: 'drink', image: 'https://images.unsplash.com/photo-1622543925917-763c34d1a86e?w=400&q=80' },
  { id: 'drk-15', name: 'Suco 1L Caixa', price: 10.00, category: 'drink', image: 'https://images.unsplash.com/photo-1613478223719-2ab802602423?w=400&q=80' },
];

const App: React.FC = () => {
  const [activePage, setActivePage] = useState<Page>(Page.MENU);
  
  // --- Notification State ---
  const [notification, setNotification] = useState<{message: string, visible: boolean} | null>(null);

  // Initialize Tables from LocalStorage or Default
  const [tables, setTables] = useState<Table[]>(() => {
    try {
      const saved = localStorage.getItem('comanda_tables');
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error("Error loading tables:", e);
    }
    return Array.from({ length: 12 }, (_, i) => ({
      id: i + 1,
      name: `Mesa ${i + 1}`,
      status: 'available',
      items: [],
      total: 0
    }));
  });

  // Global Product List State from LocalStorage
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('comanda_products');
      if (saved) {
         const parsed = JSON.parse(saved);
         if (parsed && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.error("Error loading products:", e);
    }
    return DEFAULT_MENU_ITEMS;
  });

  // Kitchen Orders State from LocalStorage
  const [kitchenOrders, setKitchenOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('comanda_kitchen_orders');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      console.error("Error loading orders:", e);
      return [];
    }
  });

  // Transaction History (for Admin Reports)
  const [history, setHistory] = useState<Transaction[]>(() => {
    try {
      const saved = localStorage.getItem('comanda_history');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  // Admin Revenue State (Calculated from history for today, or kept separate for simplicity)
  // We will derive daily revenue from history now to ensure consistency
  const dailyRevenue = history
    .filter(t => new Date(t.date).toDateString() === new Date().toDateString())
    .reduce((acc, curr) => acc + curr.total, 0);

  // --- Persistence Effects ---
  useEffect(() => {
    localStorage.setItem('comanda_tables', JSON.stringify(tables));
  }, [tables]);

  useEffect(() => {
    localStorage.setItem('comanda_products', JSON.stringify(products));
  }, [products]);

  useEffect(() => {
    localStorage.setItem('comanda_kitchen_orders', JSON.stringify(kitchenOrders));
  }, [kitchenOrders]);

  useEffect(() => {
    localStorage.setItem('comanda_history', JSON.stringify(history));
  }, [history]);

  // --- AUTOMATIC CLEANUP (5 DAYS) ---
  useEffect(() => {
    const cleanOldData = () => {
      const fiveDaysAgo = new Date();
      fiveDaysAgo.setDate(fiveDaysAgo.getDate() - 5);
      
      setHistory(prevHistory => {
        const filtered = prevHistory.filter(t => new Date(t.date) > fiveDaysAgo);
        if (filtered.length !== prevHistory.length) {
          console.log("Cleaned up old records (older than 5 days)");
        }
        return filtered;
      });
    };
    
    cleanOldData();
  }, []); // Runs once on mount

  // --- Helper: Show Toast ---
  const showToast = (message: string) => {
    setNotification({ message, visible: true });
    setTimeout(() => {
        setNotification(null);
    }, 3000);
  };


  // --- Product Management ---
  const handleCreateProduct = (newProduct: Product) => {
    setProducts(prev => {
      const updated = [...prev, newProduct];
      return updated;
    });
  };

  const handleEditProduct = (updatedProduct: Product) => {
    setProducts(prev => prev.map(p => p.id === updatedProduct.id ? updatedProduct : p));
  };

  const handleDeleteProduct = (productId: string) => {
    setProducts(prev => prev.filter(p => p.id !== productId));
  };

  // --- Table Management ---
  const handleAddTable = (tableName: string) => {
    setTables(prev => {
        const nextId = prev.length > 0 ? Math.max(...prev.map(t => t.id)) + 1 : 1;
        const newTable: Table = {
            id: nextId,
            name: tableName,
            status: 'available',
            items: [],
            total: 0
        };
        return [...prev, newTable];
    });
    showToast(`Mesa "${tableName}" criada!`);
  };

  // --- Order Logic ---
  const handleAddToTable = (tableId: number, product: Product, quantity: number) => {
    let tableName = "";
    
    // 1. Update Table State
    setTables(prev => prev.map(table => {
      if (table.id === tableId) {
        tableName = table.name; // Capture name
        const newItem: TableItem = {
            instanceId: Date.now().toString() + Math.random().toString(), // Unique ID for every instance
            productId: product.id,
            name: product.name,
            price: product.price,
            quantity: quantity
        };

        const newItems = [...table.items, newItem];
        const newTotal = newItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);

        return {
          ...table,
          status: 'occupied',
          items: newItems,
          total: newTotal
        };
      }
      return table;
    }));

    // 2. Kitchen Routing Logic
    if (product.category === 'prato1' || product.category === 'prato2') {
      const targetSection = product.category === 'prato1' ? 'kitchen1' : 'kitchen2';
      
      const newOrder: Order = {
        id: `#${Date.now().toString().slice(-4)}${Math.floor(Math.random() * 100)}`,
        tableId: tableId,
        tableName: tableName || `Mesa ${tableId}`,
        items: [`${quantity}x ${product.name}`],
        status: 'preparing',
        section: targetSection,
        time: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
      };
      setKitchenOrders(prev => [newOrder, ...prev]);
    }

    // 3. Show Confirmation
    showToast(`Pedido enviado para ${tableName || 'Mesa ' + tableId}!`);
  };

  const handleRemoveFromTable = (tableId: number, instanceId: string) => {
    setTables(prev => prev.map(table => {
        if (table.id === tableId) {
            const newItems = table.items.filter(i => i.instanceId !== instanceId);
            const newTotal = newItems.reduce((acc, item) => acc + (item.price * item.quantity), 0);
            
            return {
                ...table,
                items: newItems,
                total: newTotal,
                status: newItems.length === 0 ? 'available' : 'occupied'
            };
        }
        return table;
    }));
  };

  const handlePayment = (tableId: number, totalPaid: number) => {
    // 1. Create Transaction Record
    const table = tables.find(t => t.id === tableId);
    if (table) {
        const newTransaction: Transaction = {
            id: Date.now().toString(),
            tableId: table.id,
            tableName: table.name,
            total: totalPaid,
            itemsSummary: `${table.items.reduce((acc, i) => acc + i.quantity, 0)} itens`,
            date: new Date().toISOString(),
            timestamp: new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
        };
        setHistory(prev => [...prev, newTransaction]);
    }

    // 2. Reset or Delete Table
    // Logic: If table ID > 12 (Default count), it's a custom table -> Delete it.
    // If table ID <= 12, it's a fixed table -> Reset it.
    if (tableId > 12) {
        setTables(prev => prev.filter(t => t.id !== tableId));
    } else {
        setTables(prev => prev.map(table => {
            if (table.id === tableId) {
                return {
                    ...table,
                    status: 'available',
                    items: [],
                    total: 0
                };
            }
            return table;
        }));
    }

    showToast(`Pagamento confirmado!`);
  };

  const handleCompleteOrder = (orderId: string) => {
    setKitchenOrders(prev => prev.map(order => 
      order.id === orderId ? { ...order, status: 'ready' } : order
    ));
  };

  const handleDeleteOrder = (orderId: string) => {
    setKitchenOrders(prev => prev.filter(order => order.id !== orderId));
    showToast("Pedido excluído da cozinha");
  };

  const renderContent = () => {
    switch (activePage) {
      case Page.MENU:
        return (
          <MenuPage 
            products={products}
            tables={tables}
            onAddToTable={handleAddToTable} 
            onCreateProduct={handleCreateProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
      case Page.TABLES:
        return (
            <TablesPage 
                tables={tables} 
                onAddTable={handleAddTable}
                onRemoveItem={handleRemoveFromTable}
                onConfirmPayment={handlePayment}
            />
        );
      case Page.KITCHEN:
        return <KitchenPage orders={kitchenOrders} onCompleteOrder={handleCompleteOrder} onDeleteOrder={handleDeleteOrder} />;
      case Page.ADMIN:
        return <AdminPage history={history} />;
      default:
        return (
          <MenuPage 
            products={products}
            tables={tables}
            onAddToTable={handleAddToTable} 
            onCreateProduct={handleCreateProduct}
            onEditProduct={handleEditProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        );
    }
  };

  return (
    // Changed to h-screen to handle internal scrolling properly
    <div className="max-w-md mx-auto bg-dark-900 h-screen flex flex-col relative shadow-2xl overflow-hidden">
      {/* Content Area */}
      <main className="flex-1 overflow-hidden relative">
        {renderContent()}
      </main>

      {/* Global Notification Toast */}
      {notification && (
        <div className="fixed top-6 left-1/2 transform -translate-x-1/2 z-[60] animate-in slide-in-from-top-4 fade-in duration-300 pointer-events-none">
            <div className="bg-dark-800 border border-accent-green/50 text-white px-6 py-3 rounded-full shadow-2xl flex items-center gap-3">
                <div className="bg-accent-green/20 p-1 rounded-full text-accent-green">
                    <CheckCircle2 size={20} strokeWidth={3} />
                </div>
                <span className="font-bold text-sm tracking-wide">{notification.message}</span>
            </div>
        </div>
      )}

      {/* Bottom Navigation */}
      <BottomNav activePage={activePage} setPage={setActivePage} />
    </div>
  );
};

export default App;