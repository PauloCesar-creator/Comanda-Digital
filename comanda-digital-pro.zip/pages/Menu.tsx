import React, { useState } from 'react';
import { Menu as MenuIcon, Search, Pencil, Trash2, Plus, Beer,  GlassWater, Utensils, X, Image as ImageIcon, ChefHat, Minus, PenSquare } from 'lucide-react';
import { Product, CategoryType, Table } from '../types';

interface MenuPageProps {
  products: Product[];
  tables: Table[];
  onAddToTable: (tableId: number, product: Product, quantity: number) => void;
  onCreateProduct: (product: Product) => void;
  onEditProduct: (product: Product) => void;
  onDeleteProduct: (productId: string) => void;
}

export const MenuPage: React.FC<MenuPageProps> = ({ 
    products,
    tables,
    onAddToTable, 
    onCreateProduct, 
    onEditProduct, 
    onDeleteProduct 
}) => {
  // State for category filter (null = show all)
  const [activeCategory, setActiveCategory] = useState<CategoryType | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  
  // --- Flow State ---
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [flowStep, setFlowStep] = useState<'none' | 'quantity' | 'table'>('none');
  const [quantity, setQuantity] = useState(1);

  // --- CRUD Modals State ---
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // --- Custom Item (Avulso) State ---
  const [isCustomItemModalOpen, setIsCustomItemModalOpen] = useState(false);
  const [customItemName, setCustomItemName] = useState('');
  const [customItemPrice, setCustomItemPrice] = useState('');
  const [customItemQuantity, setCustomItemQuantity] = useState(1);

  // --- Form State (Standard Product) ---
  const [formName, setFormName] = useState('');
  const [formPrice, setFormPrice] = useState(''); 
  const [formImage, setFormImage] = useState('');
  const [formCategory, setFormCategory] = useState<CategoryType>('prato1');
  const [formObservations, setFormObservations] = useState('');

  // Category Definitions for UI Order and Labels
  const categoryConfig: { id: CategoryType; label: string; icon: React.ReactNode }[] = [
    { id: 'prato1', label: 'Prato 1', icon: <ChefHat size={18} /> },
    { id: 'prato2', label: 'Prato 2', icon: <Utensils size={18} /> },
    { id: 'alcohol', label: 'Bebidas', icon: <Beer size={18} /> },
    { id: 'drink', label: 'S/ Álcool', icon: <GlassWater size={18} /> },
  ];

  // Helper: Format currency
  const formatCurrencyDisplay = (value: string) => {
    if (!value) return "";
    const number = parseInt(value) / 100;
    return number.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
  };

  const handlePriceChange = (e: React.ChangeEvent<HTMLInputElement>, setter: (val: string) => void) => {
    const rawValue = e.target.value.replace(/\D/g, "");
    setter(rawValue);
  };

  // --- Filter Toggle Logic ---
  const toggleCategory = (catId: CategoryType) => {
    if (activeCategory === catId) {
        setActiveCategory(null); // Deactivate if already active
    } else {
        setActiveCategory(catId); // Activate new
    }
  };

  // --- Order Flow Handlers ---
  const startOrderFlow = (product: Product) => {
    setSelectedProduct(product);
    setQuantity(1);
    setFlowStep('quantity');
  };

  const handleQuantityNext = () => {
    setFlowStep('table');
  };

  const handleConfirmOrder = (tableId: number) => {
    if (selectedProduct) {
      onAddToTable(tableId, selectedProduct, quantity);
      setFlowStep('none');
      setSelectedProduct(null);
    }
  };

  // --- Custom Item Handler ---
  const handleCustomItemSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customItemName.trim() || !customItemPrice) return;

    const price = parseFloat(customItemPrice) / 100;
    
    // Create a temporary product object
    const tempProduct: Product = {
        id: `custom-${Date.now()}`,
        name: customItemName,
        price: price,
        category: 'prato1',
        image: 'https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=400&q=80',
        observations: '(Item Avulso)'
    };

    setSelectedProduct(tempProduct);
    setQuantity(customItemQuantity);
    setIsCustomItemModalOpen(false);
    
    // Reset fields
    setCustomItemName('');
    setCustomItemPrice('');
    setCustomItemQuantity(1);

    // Jump straight to table selection
    setFlowStep('table');
  };

  // --- CRUD Handlers ---
  const openCreateModal = () => {
    setEditingProduct(null);
    setFormName('');
    setFormPrice('');
    setFormImage('');
    setFormCategory('prato1');
    setFormObservations('');
    setIsFormModalOpen(true);
  };

  const openEditModal = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingProduct(product);
    setFormName(product.name);
    setFormPrice((product.price * 100).toFixed(0));
    setFormImage(product.image);
    setFormCategory(product.category);
    setFormObservations(product.observations || '');
    setIsFormModalOpen(true);
  };

  const openDeleteModal = (product: Product, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingProduct(product);
    setIsDeleteModalOpen(true);
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim() || !formPrice) {
        alert("Preencha campos obrigatórios");
        return;
    }

    const finalPrice = parseFloat(formPrice) / 100;
    const newProd: Product = {
      id: editingProduct ? editingProduct.id : `${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      name: formName,
      price: finalPrice,
      category: formCategory,
      image: formImage.trim() || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&h=400&fit=crop', 
      isAlcoholic: formCategory === 'alcohol',
      observations: formObservations.trim()
    };

    if (editingProduct) {
        onEditProduct(newProd);
    } else {
        onCreateProduct(newProd);
    }
    setIsFormModalOpen(false);
  };

  const confirmDelete = () => {
    if (editingProduct) {
        onDeleteProduct(editingProduct.id);
        setIsDeleteModalOpen(false);
        setEditingProduct(null);
    }
  };

  return (
    <div className="flex flex-col h-screen bg-dark-800 text-white relative overflow-hidden">
      
      {/* Scrollable Container */}
      <div className="flex-1 overflow-y-auto pb-32 scrollbar-hide">
        
        {/* Header (Scrolls away) */}
        <header className="flex items-center justify-between px-6 py-6 bg-dark-800 border-b border-dark-700/30">
          <button className="p-2 -ml-2 text-gray-400 hover:text-white">
            <MenuIcon size={28} />
          </button>
          <h1 className="text-xl font-bold tracking-wide">Cardápio</h1>
          <div className="w-8"></div>
        </header>

        {/* --- STICKY FILTERS AREA --- */}
        <div className="sticky top-0 z-40 bg-dark-800/95 backdrop-blur-md shadow-lg border-b border-dark-700/50 pb-2">
          {/* Categories */}
          <div className="flex justify-center gap-2 py-4 px-2 overflow-x-auto scrollbar-hide">
            {categoryConfig.map((cat) => (
              <CategoryButton 
                key={cat.id}
                icon={cat.icon} 
                label={cat.label.toUpperCase()} 
                isActive={activeCategory === cat.id} 
                onClick={() => toggleCategory(cat.id)} 
              />
            ))}
          </div>

          {/* Search */}
          <div className="px-6 mb-2">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-500" size={18} />
              <input 
                type="text" 
                placeholder="Buscar no cardápio..." 
                className="w-full bg-dark-700/50 text-gray-300 placeholder-gray-500 rounded-lg py-3 pl-11 pr-4 focus:outline-none focus:ring-1 focus:ring-primary-500 border border-dark-600/50"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Lançamento Avulso Button */}
          <div className="px-6 pb-2">
            <button 
              onClick={() => setIsCustomItemModalOpen(true)}
              className="w-full bg-dark-900 border border-dashed border-dark-600 rounded-lg py-2 px-4 flex items-center justify-center gap-2 group hover:border-primary-500 transition-colors"
            >
              <PenSquare size={16} className="text-primary-500" />
              <span className="text-primary-500 font-bold text-[10px] uppercase tracking-wider">Lançamento Avulso (Fora do Menu)</span>
            </button>
          </div>
        </div>

        {/* Product List Content */}
        <div className="px-6 space-y-8 pt-6">
          {categoryConfig.map((cat) => {
            if (activeCategory && activeCategory !== cat.id) return null;

            const sectionProducts = products.filter(p => 
              p.category === cat.id && 
              p.name.toLowerCase().includes(searchTerm.toLowerCase())
            );

            if (sectionProducts.length === 0 && !activeCategory) return null; 
            
            return (
              <div key={cat.id} className="animate-in fade-in slide-in-from-bottom-2 duration-300">
                <div className="flex items-center gap-3 mb-4 border-b border-dark-700/50 pb-2">
                  <span className="text-primary-500">{cat.icon}</span>
                  <h2 className="text-sm font-bold text-gray-400 tracking-widest uppercase">{cat.label}</h2>
                  <span className="text-[10px] bg-dark-700 text-gray-500 px-2 py-0.5 rounded-full ml-auto font-bold">
                    {sectionProducts.length}
                  </span>
                </div>

                <div className="space-y-3">
                  {sectionProducts.map((product) => (
                    <div key={product.id} onClick={() => startOrderFlow(product)} className="bg-dark-700/40 rounded-xl p-3 flex items-center shadow-md border border-dark-600/30 cursor-pointer active:scale-[0.98] transition-transform">
                      <div className="w-16 h-16 rounded-lg overflow-hidden flex-shrink-0 bg-dark-600 border border-dark-500/20">
                        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                      </div>
                      <div className="flex-1 ml-4 overflow-hidden">
                        <h3 className="text-white font-bold text-base truncate">{product.name}</h3>
                        <span className="text-accent-green font-bold text-sm">R$ {product.price.toFixed(2)}</span>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={(e) => openEditModal(product, e)} className="p-2 bg-dark-600/50 rounded-lg text-blue-400">
                          <Pencil size={14} />
                        </button>
                        <button onClick={(e) => openDeleteModal(product, e)} className="p-2 bg-dark-600/50 rounded-lg text-red-400">
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* FAB (Sticky outside scroll) */}
      <div className="absolute bottom-24 right-6 z-30">
        <button onClick={openCreateModal} className="w-14 h-14 bg-primary-500 rounded-full shadow-lg flex items-center justify-center text-dark-900 active:scale-95 transition-transform">
          <Plus size={32} strokeWidth={2.5} />
        </button>
      </div>

      {/* --- MODALS (FLOW, CUSTOM, CRUD) --- */}
      {/* (Mantidos os modais conforme a lógica anterior mas com ajustes visuais leves) */}
      
      {/* MODAL 1: QUANTIDADE */}
      {flowStep === 'quantity' && selectedProduct && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
             <div className="bg-dark-800 w-full max-w-sm rounded-2xl p-6 border border-dark-600 shadow-2xl">
                <div className="flex justify-between items-start mb-6">
                    <div>
                        <h3 className="text-xl font-bold text-white">Quantidade</h3>
                        <p className="text-primary-500 text-sm">{selectedProduct.name}</p>
                    </div>
                    <button onClick={() => setFlowStep('none')} className="text-gray-500"><X size={24} /></button>
                </div>
                <div className="flex items-center justify-center gap-6 mb-8">
                    <button onClick={() => setQuantity(Math.max(1, quantity - 1))} className="w-12 h-12 rounded-xl bg-dark-700 flex items-center justify-center text-white"><Minus size={24} /></button>
                    <span className="text-4xl font-bold text-white w-16 text-center">{quantity}</span>
                    <button onClick={() => setQuantity(quantity + 1)} className="w-12 h-12 rounded-xl bg-dark-700 flex items-center justify-center text-white"><Plus size={24} /></button>
                </div>
                <button onClick={handleQuantityNext} className="w-full bg-primary-500 text-dark-900 font-bold py-4 rounded-xl">Continuar</button>
             </div>
        </div>
      )}

      {/* MODAL 2: MESA */}
      {flowStep === 'table' && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-dark-800 w-full max-w-md rounded-2xl p-6 border border-dark-600 shadow-2xl">
            <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">Escolha a Mesa</h3>
                <button onClick={() => setFlowStep('none')} className="text-gray-500"><X size={24} /></button>
            </div>
            <div className="grid grid-cols-3 gap-3 max-h-[50vh] overflow-y-auto pr-1">
                {tables.map((table) => (
                    <button 
                        key={table.id} 
                        onClick={() => handleConfirmOrder(table.id)} 
                        className={`aspect-square p-2 rounded-xl flex flex-col items-center justify-center border ${
                            table.status === 'occupied' ? 'bg-red-500/10 border-red-500/30 text-red-500' : 'bg-yellow-500/5 border-yellow-500/30 text-yellow-400'
                        }`}
                    >
                        <span className="text-xs font-bold text-center line-clamp-2">{table.name}</span>
                    </button>
                ))}
            </div>
          </div>
        </div>
      )}

      {/* MODAL: ITEM AVULSO */}
      {isCustomItemModalOpen && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
             <div className="bg-dark-800 w-full max-w-sm rounded-2xl p-6 border border-dark-600 shadow-2xl">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2"><PenSquare size={20} className="text-primary-500" />Item Avulso</h3>
                    <button onClick={() => setIsCustomItemModalOpen(false)} className="text-gray-500"><X size={24} /></button>
                </div>
                <form onSubmit={handleCustomItemSubmit} className="space-y-4">
                    <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Nome do Item</label>
                        <input type="text" value={customItemName} onChange={(e) => setCustomItemName(e.target.value)} className="w-full bg-dark-700 border border-dark-600 rounded-lg p-3 text-white focus:border-primary-500 outline-none" placeholder="Ex: Prato Especial" autoFocus required />
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Valor</label>
                        <div className="relative">
                            <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">R$</span>
                            <input type="tel" inputMode="numeric" value={formatCurrencyDisplay(customItemPrice)} onChange={(e) => handlePriceChange(e, setCustomItemPrice)} className="w-full bg-dark-700 border border-dark-600 rounded-lg p-3 pl-10 text-white focus:border-primary-500 outline-none" placeholder="0,00" required />
                        </div>
                    </div>
                    <div>
                        <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Quantidade</label>
                        <div className="flex items-center gap-3">
                            <button type="button" onClick={() => setCustomItemQuantity(prev => Math.max(1, prev - 1))} className="w-12 h-12 bg-dark-700 rounded-lg border border-dark-600 flex items-center justify-center text-white"><Minus size={20} /></button>
                            <input type="number" value={customItemQuantity} onChange={(e) => setCustomItemQuantity(Math.max(1, parseInt(e.target.value) || 1))} className="flex-1 bg-dark-700 border border-dark-600 rounded-lg h-12 text-center text-white font-bold outline-none" />
                            <button type="button" onClick={() => setCustomItemQuantity(prev => prev + 1)} className="w-12 h-12 bg-dark-700 rounded-lg border border-dark-600 flex items-center justify-center text-white"><Plus size={20} /></button>
                        </div>
                    </div>
                    <button type="submit" className="w-full bg-primary-500 text-dark-900 font-bold py-4 rounded-xl mt-2">Selecionar Mesa</button>
                </form>
             </div>
        </div>
      )}

      {/* MODAL: FORMULÁRIO PRODUTO */}
      {isFormModalOpen && (
        <div className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-dark-800 w-full max-w-md rounded-2xl p-6 border border-dark-600 shadow-2xl max-h-[90vh] overflow-y-auto">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold text-white">{editingProduct ? 'Editar Item' : 'Novo Item'}</h3>
                <button onClick={() => setIsFormModalOpen(false)} className="p-2 bg-dark-700 rounded-full text-gray-400"><X size={20} /></button>
            </div>
            <form onSubmit={handleFormSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Nome</label>
                <input type="text" value={formName} onChange={e => setFormName(e.target.value)} className="w-full bg-dark-700 border border-dark-600 rounded-lg p-3 text-white focus:border-primary-500 outline-none" required />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-1">Preço</label>
                <div className="relative">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 font-bold">R$</span>
                    <input type="tel" inputMode="numeric" value={formatCurrencyDisplay(formPrice)} onChange={(e) => handlePriceChange(e, setFormPrice)} className="w-full bg-dark-700 border border-dark-600 rounded-lg p-3 pl-10 text-white focus:border-primary-500 outline-none" required />
                </div>
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-400 uppercase mb-2">Categoria</label>
                <div className="grid grid-cols-2 gap-2">
                  {categoryConfig.map((cat) => (
                      <button key={cat.id} type="button" onClick={() => setFormCategory(cat.id)} className={`p-3 rounded-lg border text-xs font-bold transition-all ${formCategory === cat.id ? 'bg-primary-500/20 border-primary-500 text-primary-500' : 'bg-dark-700 border-dark-600 text-gray-400'}`}>{cat.label}</button>
                  ))}
                </div>
              </div>
              <button type="submit" className="w-full bg-primary-500 text-dark-900 font-bold py-4 rounded-xl mt-4">Salvar</button>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: EXCLUSÃO */}
      {isDeleteModalOpen && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm">
            <div className="bg-dark-800 rounded-xl p-6 border border-dark-600 max-w-sm w-full">
                <h3 className="text-xl font-bold mb-2">Excluir Produto?</h3>
                <p className="text-gray-400 mb-6 text-sm">Tem certeza que deseja excluir "{editingProduct?.name}"?</p>
                <div className="flex gap-3">
                    <button onClick={() => setIsDeleteModalOpen(false)} className="flex-1 py-3 rounded-lg bg-dark-700 text-white font-bold">Cancelar</button>
                    <button onClick={confirmDelete} className="flex-1 py-3 rounded-lg bg-red-500/20 text-red-500 border border-red-500/50 font-bold">Excluir</button>
                </div>
            </div>
        </div>
      )}
    </div>
  );
};

const CategoryButton: React.FC<{ icon: React.ReactNode; label: string; isActive: boolean; onClick: () => void; }> = ({ icon, label, isActive, onClick }) => (
  <button onClick={onClick} className="flex flex-col items-center gap-2 group min-w-[70px]">
    <div className={`w-11 h-11 rounded-full flex items-center justify-center transition-all duration-300 ${isActive ? 'bg-primary-500 text-dark-900' : 'bg-dark-600/50 text-gray-400 group-hover:bg-dark-600'}`}>{icon}</div>
    <span className={`text-[9px] font-bold tracking-wider ${isActive ? 'text-primary-500' : 'text-gray-500'}`}>{label}</span>
  </button>
);