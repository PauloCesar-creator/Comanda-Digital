export enum Page {
  MENU = 'MENU',
  TABLES = 'TABLES',
  KITCHEN = 'KITCHEN',
  ADMIN = 'ADMIN'
}

export type CategoryType = 'prato1' | 'prato2' | 'drink' | 'alcohol';

export interface Product {
  id: string;
  name: string;
  price: number;
  category: CategoryType;
  image: string;
  isAlcoholic?: boolean;
  observations?: string; // New field for item notes/description
}

export interface TableItem {
  instanceId: string; // Unique ID for this specific order line on the table
  productId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Table {
  id: number;
  name: string; // Custom name for the table (e.g., "Mesa 1", "João", "VIP")
  status: 'available' | 'occupied' | 'reserved' | 'payment';
  items: TableItem[]; 
  total: number; // This will now represent the subtotal internally, calculated on render for display
}

export interface Order {
  id: string;
  tableId: number;
  tableName: string; // Store the table name at the time of order
  items: string[]; // Descriptions like "2x X-Bacon"
  status: 'pending' | 'preparing' | 'ready';
  section: 'kitchen1' | 'kitchen2'; // Routing
  time: string;
}

export interface Transaction {
  id: string;
  tableId: number;
  tableName: string;
  total: number;
  itemsSummary: string; // e.g. "3 items"
  date: string; // ISO String for filtering
  timestamp: string; // Display time (HH:MM)
}