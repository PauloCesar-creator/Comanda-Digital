import React from 'react';
import { Clock, CheckCircle, ChefHat, Trash2 } from 'lucide-react';
import { Order } from '../types';

interface KitchenPageProps {
    orders: Order[];
    onCompleteOrder: (id: string) => void;
    onDeleteOrder: (id: string) => void;
}

export const KitchenPage: React.FC<KitchenPageProps> = ({ orders, onCompleteOrder, onDeleteOrder }) => {
  
  // Helper to render a list of orders
  const OrderList = ({ sectionOrders }: { sectionOrders: Order[] }) => (
    <div className="space-y-4">
        {sectionOrders.length === 0 ? (
             <div className="flex flex-col items-center justify-center py-10 text-gray-500 opacity-30 border border-dashed border-dark-600 rounded-xl">
                <ChefHat size={32} className="mb-2" />
                <p className="text-xs">Sem pedidos</p>
             </div>
        ) : (
            sectionOrders.map((order) => (
            <div key={order.id} className={`bg-dark-700 rounded-xl p-4 border-l-4 shadow-lg transition-all ${order.status === 'ready' ? 'border-l-accent-green opacity-50' : 'border-l-primary-500'}`}>
                <div className="flex justify-between items-start mb-2">
                    <div>
                        <h3 className="text-md font-bold text-white flex items-center gap-2">
                            {/* Display Table Name if available, otherwise fallback to ID */}
                            <span className="text-yellow-400">{order.tableName || `Mesa ${order.tableId}`}</span>
                        </h3>
                        <div className="flex items-center gap-1 text-[10px] text-gray-400">
                        <Clock size={10} />
                        <span>{order.time}</span>
                        </div>
                    </div>
                    
                    {/* Delete Button */}
                    <button 
                        onClick={() => onDeleteOrder(order.id)}
                        className="p-1 text-dark-500 hover:text-red-500 transition-colors"
                        title="Excluir pedido"
                    >
                        <Trash2 size={16} />
                    </button>
                </div>

                <ul className="space-y-1 mb-3">
                {order.items.map((item, idx) => (
                    <li key={idx} className="text-gray-300 text-sm font-bold border-b border-dashed border-dark-600 pb-1 last:border-0">
                    {item}
                    </li>
                ))}
                </ul>

                {order.status !== 'ready' && (
                    <button 
                        onClick={() => onCompleteOrder(order.id)}
                        className="w-full bg-accent-green text-dark-900 hover:bg-emerald-400 py-2 rounded-lg text-xs font-bold flex items-center justify-center gap-2 transition-colors"
                    >
                        <CheckCircle size={14} />
                        Concluir
                    </button>
                )}
            </div>
            ))
        )}
    </div>
  );

  const kitchen1Orders = orders.filter(o => o.section === 'kitchen1' && o.status !== 'ready');
  const kitchen2Orders = orders.filter(o => o.section === 'kitchen2' && o.status !== 'ready');

  return (
    <div className="min-h-screen bg-dark-800 text-white pb-24 flex flex-col">
      <header className="p-6 pb-2">
        <h1 className="text-2xl font-bold">Cozinha</h1>
      </header>

      <div className="flex-1 overflow-x-auto flex gap-4 p-4 snap-x">
        {/* Kitchen 1 Column */}
        <div className="flex-1 min-w-[280px] bg-dark-900/50 rounded-2xl p-4 border border-dark-700 snap-center">
            <h2 className="text-primary-500 font-bold mb-4 flex items-center gap-2 border-b border-dark-700 pb-2">
                <ChefHat size={20} />
                COZINHA 1 (Prato 1)
                <span className="ml-auto bg-dark-700 text-white text-xs px-2 py-0.5 rounded-full">{kitchen1Orders.length}</span>
            </h2>
            <OrderList sectionOrders={kitchen1Orders} />
        </div>

        {/* Kitchen 2 Column */}
        <div className="flex-1 min-w-[280px] bg-dark-900/50 rounded-2xl p-4 border border-dark-700 snap-center">
             <h2 className="text-blue-400 font-bold mb-4 flex items-center gap-2 border-b border-dark-700 pb-2">
                <ChefHat size={20} />
                COZINHA 2 (Prato 2)
                <span className="ml-auto bg-dark-700 text-white text-xs px-2 py-0.5 rounded-full">{kitchen2Orders.length}</span>
            </h2>
            <OrderList sectionOrders={kitchen2Orders} />
        </div>
      </div>
    </div>
  );
};